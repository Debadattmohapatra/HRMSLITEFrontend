import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Mail, Building2, Calendar, CheckCircle } from 'lucide-react';
import { employeeAPI } from '../api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';

const EmployeeDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchEmployeeDetails();
  }, [id]);

  const fetchEmployeeDetails = async () => {
    try {
      setLoading(true);
      setError(null);

      const [empResponse, attResponse] = await Promise.all([
        employeeAPI.getById(id),
        employeeAPI.getAttendance(id),
      ]);

      setEmployee(empResponse.data.data);
      setAttendance(attResponse.data.data.attendance);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load employee details');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <Loading message="Loading employee details..." />;
  }

  if (error) {
    return (
      <div className="space-y-4">
        <button onClick={() => navigate('/employees')} className="btn-secondary flex items-center space-x-2">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Employees</span>
        </button>
        <ErrorMessage message={error} />
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="space-y-4">
        <button onClick={() => navigate('/employees')} className="btn-secondary flex items-center space-x-2">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Employees</span>
        </button>
        <ErrorMessage message="Employee not found" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button onClick={() => navigate('/employees')} className="btn-secondary flex items-center space-x-2">
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Employees</span>
      </button>

      {/* Employee Info Card */}
      <div className="card">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{employee.full_name}</h1>
            <p className="text-gray-600 mt-1">Employee ID: {employee.employee_id}</p>
          </div>
          <span className="px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
            <CheckCircle className="w-4 h-4 inline mr-1" />
            {employee.total_present_days} Days Present
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="text-gray-900 font-medium">{employee.email}</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Department</p>
              <p className="text-gray-900 font-medium">{employee.department}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Attendance Records */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Attendance History</h2>
          <Link to="/attendance" className="text-sm text-primary-600 hover:text-primary-700">
            View all attendance
          </Link>
        </div>

        {attendance.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600">No attendance records found for this employee</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="table-header">
                <tr>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {attendance.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="table-cell text-gray-900">{record.date}</td>
                    <td className="table-cell">
                      <span
                        className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          record.status === 'present'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmployeeDetail;