import { useState, useEffect } from 'react';
import { Plus, Search, Filter, Edit, Trash2, MoreVertical, Calendar, CheckCircle, XCircle } from 'lucide-react';
import { attendanceAPI, employeeAPI } from '../api';
import Modal from '../components/Model';

const Attendance = () => {
  const [attendance, setAttendance] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [formData, setFormData] = useState({
    employee: '',
    date: new Date().toISOString().split('T')[0],
    status: 'present',
    check_in_time: '09:00',
    check_out_time: '17:00',
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [attendanceRes, employeesRes] = await Promise.all([
        attendanceAPI.getAll(),
        employeeAPI.getAll()
      ]);
      setAttendance(attendanceRes.data || attendanceRes || []);
      setEmployees(employeesRes.data || employeesRes || []);
    } catch (err) {
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingRecord) {
        await attendanceAPI.update(editingRecord.id, formData);
        setSuccess('Attendance record updated successfully');
      } else {
        await attendanceAPI.create(formData);
        setSuccess('Attendance record added successfully');
      }
      setIsModalOpen(false);
      resetForm();
      fetchData();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save attendance record');
      setTimeout(() => setError(null), 3000);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      try {
        await attendanceAPI.delete(id);
        setSuccess('Record deleted successfully');
        fetchData();
        setTimeout(() => setSuccess(null), 3000);
      } catch (err) {
        setError('Failed to delete record');
        setTimeout(() => setError(null), 3000);
      }
    }
  };

  const handleEdit = (record) => {
    setEditingRecord(record);
    setFormData({
      employee: record.employee,
      date: record.date,
      status: record.status,
      check_in_time: record.check_in_time || '09:00',
      check_out_time: record.check_out_time || '17:00',
      notes: record.notes || '',
    });
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setFormData({
      employee: '',
      date: new Date().toISOString().split('T')[0],
      status: 'present',
      check_in_time: '09:00',
      check_out_time: '17:00',
      notes: '',
    });
    setEditingRecord(null);
  };

  const filteredAttendance = attendance.filter(record => {
    const matchesSearch = 
      record.employee_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.employee_id_display?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const todayRecords = attendance.filter(r => r.date === new Date().toISOString().split('T')[0]);
  const presentToday = todayRecords.filter(r => r.status === 'present').length;
  const absentToday = todayRecords.filter(r => r.status === 'absent').length;

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p style={{ marginTop: '16px', color: 'var(--gray-600)' }}>Loading attendance...</p>
      </div>
    );
  }

  return (
    <div>
      {/* Page Header */}
      <div className="page-header">
        <h1 className="page-title">Attendance</h1>
        <p className="page-subtitle">Track and manage employee attendance records</p>
      </div>

      {/* Messages */}
      {error && (
        <div className="message message-error">
          <div className="message-icon">⚠️</div>
          <div className="message-content">{error}</div>
          <button className="message-close" onClick={() => setError(null)}>✕</button>
        </div>
      )}
      {success && (
        <div className="message message-success">
          <div className="message-icon">✓</div>
          <div className="message-content">{success}</div>
          <button className="message-close" onClick={() => setSuccess(null)}>✕</button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-card-header">
            <div>
              <div className="stat-card-label">Total Records</div>
              <div className="stat-card-value">{attendance.length}</div>
            </div>
            <div className="stat-card-icon blue">
              <Calendar className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <div>
              <div className="stat-card-label">Present Today</div>
              <div className="stat-card-value">{presentToday}</div>
            </div>
            <div className="stat-card-icon green">
              <CheckCircle className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <div>
              <div className="stat-card-label">Absent Today</div>
              <div className="stat-card-value">{absentToday}</div>
            </div>
            <div className="stat-card-icon red">
              <XCircle className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Card */}
      <div className="card">
        {/* Tabs */}
        <div className="tabs">
          <button
            className={`tab ${activeTab === 'all' ? 'active' : ''}`}
            onClick={() => setActiveTab('all')}
          >
            All Records
          </button>
          <button
            className={`tab ${activeTab === 'today' ? 'active' : ''}`}
            onClick={() => setActiveTab('today')}
          >
            Today
          </button>
          <button
            className={`tab ${activeTab === 'week' ? 'active' : ''}`}
            onClick={() => setActiveTab('week')}
          >
            This Week
          </button>
        </div>

        {/* Toolbar */}
        <div className="toolbar">
          <div className="toolbar-left">
            {/* Search */}
            <div className="input-group">
              <Search className="input-icon" />
              <input
                type="text"
                placeholder="Search by employee..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field"
              />
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="select-field"
              style={{ width: '150px' }}
            >
              <option value="all">All Status</option>
              <option value="present">Present</option>
              <option value="absent">Absent</option>
            </select>
          </div>

          <div className="toolbar-right">
            <button className="btn-icon">
              <Filter className="w-5 h-5" />
            </button>
            <button className="btn-icon">
              <MoreVertical className="w-5 h-5" />
            </button>
            <button
              className="btn-primary"
              onClick={() => {
                resetForm();
                setIsModalOpen(true);
              }}
            >
              <Plus className="w-5 h-5" />
              Mark Attendance
            </button>
          </div>
        </div>

        {/* Table */}
        {filteredAttendance.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">
              <Calendar className="w-16 h-16" />
            </div>
            <h3 className="empty-state-title">No attendance records found</h3>
            <p className="empty-state-message">
              {searchTerm ? 'Try adjusting your search' : 'Get started by marking attendance'}
            </p>
            {!searchTerm && (
              <button className="btn-primary" onClick={() => setIsModalOpen(true)}>
                <Plus className="w-5 h-5" />
                Mark Attendance
              </button>
            )}
          </div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Employee Name</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Check In</th>
                  <th>Check Out</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAttendance.map((record) => (
                  <tr key={record.id}>
                    <td className="font-semibold">{record.employee_id_display}</td>
                    <td className="font-semibold">{record.employee_name}</td>
                    <td className="text-gray-600">
                      {new Date(record.date).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </td>
                    <td>
                      <span className={`badge ${record.status === 'present' ? 'badge-success' : 'badge-error'}`}>
                        {record.status}
                      </span>
                    </td>
                    <td className="text-gray-600" style={{ fontFamily: 'monospace' }}>
                      {record.check_in_time || '-'}
                    </td>
                    <td className="text-gray-600" style={{ fontFamily: 'monospace' }}>
                      {record.check_out_time || '-'}
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleEdit(record)}
                          className="btn-icon"
                          style={{ padding: '6px' }}
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(record.id)}
                          className="btn-icon"
                          style={{ padding: '6px', color: 'var(--error)' }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          resetForm();
        }}
        title={editingRecord ? 'Edit Attendance Record' : 'Mark Attendance'}
      >
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Employee *</label>
              <select
                required
                value={formData.employee}
                onChange={(e) => setFormData({ ...formData, employee: e.target.value })}
                className="form-input"
              >
                <option value="">Select Employee</option>
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.employee_id} - {emp.first_name} {emp.last_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Date *</label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Status *</label>
              <select
                required
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="form-input"
              >
                <option value="present">Present</option>
                <option value="absent">Absent</option>
              </select>
            </div>

            {formData.status === 'present' && (
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Check In Time</label>
                  <input
                    type="time"
                    value={formData.check_in_time}
                    onChange={(e) => setFormData({ ...formData, check_in_time: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Check Out Time</label>
                  <input
                    type="time"
                    value={formData.check_out_time}
                    onChange={(e) => setFormData({ ...formData, check_out_time: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>
            )}

            <div className="form-group">
              <label className="form-label">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="form-input"
                rows="3"
                placeholder="Add any additional notes..."
              />
            </div>
          </div>

          <div className="modal-footer">
            <button
              type="button"
              onClick={() => {
                setIsModalOpen(false);
                resetForm();
              }}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button type="submit" className="btn-primary">
              {editingRecord ? 'Update Record' : 'Mark Attendance'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Attendance;
