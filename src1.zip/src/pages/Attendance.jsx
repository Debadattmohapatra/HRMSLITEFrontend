import { useState, useEffect } from 'react';
import { Plus, Filter, Calendar as CalendarIcon } from "lucide-react";
import { attendanceAPI, employeeAPI } from '../services/api';
import Loading from '../components/Loading';
import EmptyState from '../components/EmptyState';
import ErrorMessage from '../components/ErrorMessage';
import SuccessMessage from '../components/SuccessMessage';
import Modal from '../components/Modal';

const Attendance = () => {
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [filterDate, setFilterDate] = useState('');
  const [formData, setFormData] = useState({
    employee: '',
    date: new Date().toISOString().split('T')[0],
    status: 'present',
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchEmployees();
    fetchAttendance();
  }, []);

  useEffect(() => {
    if (filterDate) {
      fetchAttendance({ date: filterDate });
    } else {
      fetchAttendance();
    }
  }, [filterDate]);

  const fetchEmployees = async () => {
    try {
      const response = await employeeAPI.getAll();
      setEmployees(response.data.data);
    } catch (err) {
      console.error('Failed to load employees');
    }
  };

  const fetchAttendance = async (params = {}) => {
    try {
      setLoading(true);
      setError(null);
      const response = await attendanceAPI.getAll(params);
      setAttendanceRecords(response.data.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load attendance records');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.employee) {
      errors.employee = 'Employee is required';
    }

    if (!formData.date) {
      errors.date = 'Date is required';
    }

    if (!formData.status) {
      errors.status = 'Status is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      setSubmitting(true);
      await attendanceAPI.create(formData);
      setSuccess('Attendance marked successfully!');
      setShowAddModal(false);
      setFormData({
        employee: '',
        date: new Date().toISOString().split('T')[0],
        status: 'present',
      });
      fetchAttendance(filterDate ? { date: filterDate } : {});
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      const errorData = err.response?.data;
      if (errorData?.errors) {
        setFormErrors(errorData.errors);
      } else {
        setError(errorData?.message || 'Failed to mark attendance');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const clearFilter = () => {
    setFilterDate('');
  };

  if (loading && attendanceRecords.length === 0) {
    return <Loading message="Loading attendance records..." />;
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Attendance</h1>
          <p className="mt-2 text-gray-600">Track and manage employee attendance</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="btn-primary mt-4 sm:mt-0 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Mark Attendance</span>
        </button>
      </div>

      {/* Messages */}
      {error && <ErrorMessage message={error} onClose={() => setError(null)} />}
      {success && <SuccessMessage message={success} onClose={() => setSuccess(null)} />}

      {/* Filters */}
      <div className="card">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Filter by Date
            </label>
            <input
              type="date"
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              className="input-field"
            />
          </div>
          {filterDate && (
            <button onClick={clearFilter} className="btn-secondary self-end">
              Clear Filter
            </button>
          )}
        </div>
      </div>

      {/* Attendance Records */}
      {attendanceRecords.length === 0 ? (
        <EmptyState
          message={
            filterDate
              ? 'No attendance records found for the selected date'
              : 'No attendance records yet. Start marking attendance!'
          }
          action={
            !filterDate && (
              <button onClick={() => setShowAddModal(true)} className="btn-primary">
                Mark Attendance
              </button>
            )
          }
        />
      ) : (
        <div className="card overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="table-header">
                <tr>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Employee ID
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Department
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {attendanceRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="table-cell text-gray-900 font-medium">
                      {record.employee_id_display}
                    </td>
                    <td className="table-cell text-gray-900">{record.employee_name}</td>
                    <td className="table-cell text-gray-600">{record.department}</td>
                    <td className="table-cell text-gray-600">{record.date}</td>
                    <td className="table-cell">
                      <span
                        className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          record.status === 'present'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Mark Attendance Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => {
          setShowAddModal(false);
          setFormErrors({});
        }}
        title="Mark Attendance"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Employee <span className="text-red-500">*</span>
            </label>
            <select
              name="employee"
              value={formData.employee}
              onChange={handleInputChange}
              className={`input-field ${formErrors.employee ? 'border-red-500' : ''}`}
            >
              <option value="">Select an employee</option>
              {employees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.employee_id} - {emp.full_name}
                </option>
              ))}
            </select>
            {formErrors.employee && (
              <p className="mt-1 text-sm text-red-600">{formErrors.employee}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleInputChange}
              className={`input-field ${formErrors.date ? 'border-red-500' : ''}`}
            />
            {formErrors.date && (
              <p className="mt-1 text-sm text-red-600">{formErrors.date}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status <span className="text-red-500">*</span>
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              className={`input-field ${formErrors.status ? 'border-red-500' : ''}`}
            >
              <option value="present">Present</option>
              <option value="absent">Absent</option>
            </select>
            {formErrors.status && (
              <p className="mt-1 text-sm text-red-600">{formErrors.status}</p>
            )}
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setShowAddModal(false);
                setFormErrors({});
              }}
              className="btn-secondary"
              disabled={submitting}
            >
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={submitting}>
              {submitting ? 'Marking...' : 'Mark Attendance'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Attendance;