import { useState, useEffect } from 'react';
import { Users, Calendar, CheckCircle, XCircle, TrendingUp } from 'lucide-react';
import { dashboardAPI } from '../services/api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await dashboardAPI.getStats();
      setStats(response.data.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load dashboard statistics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <Loading message="Loading dashboard..." />;
  }

  if (error) {
    return <ErrorMessage message={error} onClose={() => setError(null)} />;
  }

  if (!stats) {
    return <ErrorMessage message="No data available" />;
  }

  const statCards = [
    {
      title: 'Total Employees',
      value: stats.total_employees,
      icon: Users,
      color: 'bg-blue-500',
      link: '/employees',
    },
    {
      title: 'Attendance Records',
      value: stats.total_attendance_records,
      icon: Calendar,
      color: 'bg-purple-500',
      link: '/attendance',
    },
    {
      title: "Today's Present",
      value: stats.today_stats.present,
      icon: CheckCircle,
      color: 'bg-green-500',
    },
    {
      title: "Today's Absent",
      value: stats.today_stats.absent,
      icon: XCircle,
      color: 'bg-red-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-gray-600">Overview of your HR management system</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          const Card = stat.link ? Link : 'div';
          return (
            <Card
              key={index}
              to={stat.link}
              className={`card hover:shadow-md transition-shadow ${
                stat.link ? 'cursor-pointer' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Today's Summary */}
      <div className="card">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Today's Summary</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Date</span>
            <span className="text-sm text-gray-900">{stats.today_stats.date}</span>
          </div>
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Present</span>
            <span className="text-sm font-semibold text-green-700">
              {stats.today_stats.present}
            </span>
          </div>
          <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Absent</span>
            <span className="text-sm font-semibold text-red-700">
              {stats.today_stats.absent}
            </span>
          </div>
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Total Marked</span>
            <span className="text-sm font-semibold text-blue-700">
              {stats.today_stats.total}
            </span>
          </div>
        </div>
      </div>

      {/* Departments */}
      {stats.departments && stats.departments.length > 0 && (
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Departments</h2>
          <div className="space-y-3">
            {stats.departments.map((dept, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <span className="text-sm font-medium text-gray-700">
                  {dept.department}
                </span>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-primary-600" />
                  <span className="text-sm font-semibold text-gray-900">
                    {dept.count} {dept.count === 1 ? 'employee' : 'employees'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Attendance */}
      {stats.recent_attendance && stats.recent_attendance.length > 0 && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Attendance</h2>
            <Link to="/attendance" className="text-sm text-primary-600 hover:text-primary-700">
              View all
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="table-header">
                <tr>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Employee ID
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="table-cell text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {stats.recent_attendance.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="table-cell text-gray-900 font-medium">
                      {record.employee_id_display}
                    </td>
                    <td className="table-cell text-gray-900">{record.employee_name}</td>
                    <td className="table-cell text-gray-600">{record.date}</td>
                    <td className="table-cell">
                      <span
                        className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          record.status === 'present'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;